package com.gamutkart;

public class App 
{
    public static void main( String[] args )
    {
		int i;
		int j;

		for(i=0;i<30;i++)
		{
			i += 5;
			i += 5;
   		}
	 }
}
