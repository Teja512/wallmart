#!/bin/bash
#
if [ ! -d test ];then
	mkdir test
fi
